package com.cg.employee.ui;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;
import com.cg.employee.service.EmployeeService;
import com.cg.employee.service.EmployeeServiceImpl;

public class Client {
	public static void main(String[] args) throws EmployeeException {
		EmployeeService service = new EmployeeServiceImpl();
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		@SuppressWarnings("resource")
		Scanner sc1 = new Scanner(System.in);
		int ch = 0;
		do {
			System.out.println("**************************");
			System.out.println("1. Add Employee Details:  ");
			System.out.println("2. Search Employee Details:  ");
			System.out.println("3. Update Employee Details:  ");
			System.out.println("4. Display Employee List:  ");
			System.out.println("5. Exit: ");
			System.out
					.println("---Press 0 to find how to insert valid inputs---");
			System.out.println("Enter your choice");

			ch = sc.nextInt();
			switch (ch) {
			case 1:
				Employee employee = new Employee();
				do {

					System.out.println("Enter Employee Name:");
					String name = sc1.nextLine();

					System.out.println("Enter Age:");
					int age = 0;
					try {
						age = sc.nextInt();

					} catch (InputMismatchException e) {
						System.err
								.println("Please insert integers value only!!!");
						break;
					}

					System.out.println("Enter Contact No.:");
					String mob = sc.next();

					System.out.println("Enter Email Id");
					String mail = sc.next();

					System.out.println("Enter your salary");
					long sal = sc.nextLong();

					System.out.println("Enter Employee Project Name:");
					String pname = sc.next();

					employee.setEmpName(name);
					employee.setEmpAge(age);
					employee.setEmpPhone(mob);
					employee.setEmpEmail(mail);
					employee.setEmpSal(sal);
					employee.setProjName(pname);

					if (service.ValidateDetails(employee))
						break;
					else
						System.err
								.println("Insert Valid details in the given format");
				} while (true);
				int pId = service.addEmployee(employee);
				System.out.println();
				System.out.println("Record inserted succesfully of EmployeeId:"
						+ pId);
				break;

			case 2:
				Employee emp = new Employee();
				System.out.println("Enter EmpId: ");
				int eId = sc.nextInt();
				emp = service.searchEmployee(eId);
				if (emp == null)
					System.err.println("Record not found...\n");
				else {

					System.out.println(emp.toString());
				}
				break;

			case 3:

				System.out.println("Enter EmpId: ");
				eId = sc.nextInt();
				employee = service.searchEmployee(eId);
				if (employee == null)
					System.err.println("Record not found...\n");
				else {
					System.out.println("Enter new Mobile No: ");
					String mobno = sc.next();
					employee.setEmpPhone(mobno);
					employee = service.updateEmployee(employee);
					System.out.println("Record Updated");
					System.out.println(employee.toString());
				}
				break;
			case 0:
				System.out
						.println("Insert your full name in this format------'Rishabh Srivastava'");
				System.out.println("Insert your EmailId which ends with .com");
				System.out
						.println("Insert only 10 digits contact no & number can't start with zero");
				System.out
						.println("Kindly insert integers values in age & salary fields\n");
				break;
			case 4:
				System.out.println("Enter Project Name: ");
				String pname = sc.next();
				ArrayList<Employee> list = service.getEmployeeList(pname);
				if (list.size() == 0) {
					System.err.println("No student enrolled to this record...");
				} else {
					System.out.println("Details of the employee enrolled in the projects are given below");
					for (Employee e : list) {
						
						System.out.println(e.getEmpName() + " "
								+ e.getEmpEmail());
						System.out.println();
					}
				}

			}// end of switch
		} while (ch != 5);

	}
}
