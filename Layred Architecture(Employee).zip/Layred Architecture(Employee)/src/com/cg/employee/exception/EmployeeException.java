package com.cg.employee.exception;

@SuppressWarnings("serial")
public class EmployeeException extends Exception {
public EmployeeException(String message) {
super(message);
		}}