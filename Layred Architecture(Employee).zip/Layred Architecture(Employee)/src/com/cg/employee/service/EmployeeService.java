package com.cg.employee.service;

import java.util.ArrayList;

import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;

public interface EmployeeService {
	public int addEmployee(Employee employee) throws EmployeeException;
	public Employee searchEmployee(int empId) throws EmployeeException;
	public Employee updateEmployee(Employee employee) throws EmployeeException;
	public ArrayList<Employee> getEmployeeList(String projName) throws EmployeeException;
	public boolean ValidateDetails(Employee ed) throws EmployeeException;
	public boolean ValidateName(String name) throws EmployeeException;
	public boolean ValidateMail(String email) throws EmployeeException;
	public boolean ValidateMobile(String mobile) throws EmployeeException;
	public boolean ValidateAge(int age) throws EmployeeException;
	public boolean ValidateSalary(Long salary) throws EmployeeException;
	
}
