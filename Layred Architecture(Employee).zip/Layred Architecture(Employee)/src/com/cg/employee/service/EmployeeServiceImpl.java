package com.cg.employee.service;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.employee.dao.EmployeeDAO;
import com.cg.employee.dao.EmployeeDAOImpl;
import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService {
	
	EmployeeDAO dao;
	public EmployeeServiceImpl() {
		dao=new EmployeeDAOImpl();
	}
	@Override
	public int addEmployee(Employee employee) throws EmployeeException {
		int empId=dao.addEmployee(employee);
		return empId;
	}

	@Override
	public Employee searchEmployee(int empId) throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.searchEmployee(empId);
	}

	@Override
	public Employee updateEmployee(Employee employee) throws EmployeeException{
		// TODO Auto-generated method stub
		return dao.updateEmployee(employee);
	}

	@Override
	public ArrayList<Employee> getEmployeeList(String projName) throws EmployeeException{
		// TODO Auto-generated method stub
		return dao.getEmployeeList(projName);
	}
	@Override
	public boolean ValidateDetails(Employee ed) throws EmployeeException{
		 {
			if(ValidateMail(ed.getEmpEmail()) == true && ValidateMobile(ed.getEmpPhone()) == true && ValidateName(ed.getEmpName()) == true && ValidateSalary(ed.getEmpSal()) == true&& ValidateAge(ed.getEmpAge()) == true )
			return true;
			else
				return false;
		}
	}
	@Override
	public boolean ValidateName(String name) throws EmployeeException{
		Pattern pat=Pattern.compile("[A-Z]{1}[a-z]{2,30}[ ][A-Z]{1}[a-z]{2,30}");
		Matcher mat=pat.matcher(name);
		return mat.matches();
	}
	@Override
	public boolean ValidateMail(String email) throws EmployeeException{
		Pattern pat=Pattern.compile("[a-z0-9@]{2,55}.com");
		Matcher mat=pat.matcher(email);
		return mat.matches();
	}
	@Override
	public boolean ValidateMobile(String mobile) throws EmployeeException{
		Pattern pat=Pattern.compile("[1-9]{1}[0-9]{9}");
		Matcher mat=pat.matcher(mobile);
		return mat.matches();
	}
	@Override
	public boolean ValidateAge(int age) throws EmployeeException{
		Pattern pat=Pattern.compile("[1-9]{1,3}");
		String s=String.valueOf(age);
		Matcher mat=pat.matcher(s);
		return mat.matches();
	}
	@Override
	public boolean ValidateSalary(Long salary) throws EmployeeException{
		Pattern pat=Pattern.compile("[1-9][0-9]{3,8}");
		String s=salary.toString();
		Matcher mat=pat.matcher(s);
		return mat.matches();
	}

}
