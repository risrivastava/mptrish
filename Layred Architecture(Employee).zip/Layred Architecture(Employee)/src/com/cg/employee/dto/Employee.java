package com.cg.employee.dto;

public class Employee {
	private static int EmpId;
	private String EmpName;
	private long EmpSal;
	private String ProjName;
	private String EmpEmail;
	private String EmpPhone;
	private int EmpAge;
	
	public static int getEmpId() {
		return EmpId;
	}
	public void setEmpId(int empId) {
		EmpId = empId;
	}
	public String getEmpName() {
		return EmpName;
	}
	public void setEmpName(String empName) {
		EmpName = empName;
	}
	public long getEmpSal() {
		return EmpSal;
	}
	public void setEmpSal(long empSal) {
		EmpSal = empSal;
	}
	public String getProjName() {
		return ProjName;
	}
	public void setProjName(String projName) {
		ProjName = projName;
	}
	public String getEmpEmail() {
		return EmpEmail;
	}
	public void setEmpEmail(String empEmail) {
		EmpEmail = empEmail;
	}
	public String getEmpPhone() {
		return EmpPhone;
	}
	public void setEmpPhone(String empPhone) {
		EmpPhone = empPhone;
	}
	public int getEmpAge() {
		return EmpAge;
	}
	public void setEmpAge(int empAge) {
		EmpAge = empAge;
	}
	@Override
	public String toString() {
		return " Employee Details are given below.\n Employee Name: " + EmpName + "\n Employee Salary: " + EmpSal
				+ "\n Project Name: " + ProjName + "\n Employee Email: " + EmpEmail
				+ "\n Employee Phone Number: " + EmpPhone + "\n Employee Age: " + EmpAge + "";
	}
	

}
