package com.cg.employee.test;

import org.junit.Assert;
import org.junit.Test;

import com.cg.employee.exception.EmployeeException;
import com.cg.employee.service.EmployeeService;
import com.cg.employee.service.EmployeeServiceImpl;

public class EmployeeTest {
	
	EmployeeService es = new EmployeeServiceImpl();
	
	@Test(expected = NullPointerException.class)
	public void test_ValidateName_null() throws EmployeeException{
		es.ValidateName(null);
	}

	@Test
	public void test_ValidateName_v1() throws EmployeeException{
		String name = "Aete121";
		boolean result = es.ValidateName(name);
		Assert.assertEquals(false, result);

	}

	@Test
	public void test_ValidateName_v2() throws EmployeeException{
		String name = "Amita Singh";
		boolean result = es.ValidateName(name);
		Assert.assertEquals(true, result);
	}

	@Test
	public void test_ValidateName_v3() throws EmployeeException{
		String name = "amita";
		boolean result = es.ValidateName(name);
		Assert.assertEquals(false, result);
	}

	@Test
	public void test_ValidateSalary_v1() throws EmployeeException{
		long salary = 5;
		boolean result = es.ValidateSalary(salary);
		Assert.assertEquals(false, result);
	}
	@Test
	public void test_ValidateSalary_v2() throws EmployeeException{
		long salary = 0100;
		boolean result = es.ValidateSalary(salary);
		Assert.assertEquals(false, result);
	}
	@Test
	public void test_ValidateSalary_v3() throws EmployeeException{
		long salary = 2100;
		boolean result = es.ValidateSalary(salary);
		Assert.assertEquals(true, result);
	}
	@Test
	public void test_ValidateAge_v1() throws EmployeeException{
		int age1 = 21;
		boolean result=es.ValidateAge(age1);
		Assert.assertEquals(true, result);
	}
	@Test
	public void test_ValidateAge_v2() throws EmployeeException{
		int age1 = 1111;
		boolean result=es.ValidateAge(age1);
		Assert.assertEquals(false, result);
	}
	@Test
	public void test_ValidateMail_v1() throws EmployeeException{
		String mail="rishabh@capgemini.com";
		boolean result=es.ValidateMail(mail);
		Assert.assertEquals(true, result);
	}
	@Test
	public void test_ValidateMail_v2() throws EmployeeException{
		String mail="rishabh@capgemini";
		boolean result=es.ValidateMail(mail);
		Assert.assertEquals(false, result);
	}
	
	@Test
	public void test_ValidateNumber_v1() throws EmployeeException{
		String num="7055178203";
		boolean result=es.ValidateMobile(num);
		Assert.assertEquals(true, result);
	}
	@Test
	public void test_ValidateNumber_v2() throws EmployeeException{
		String num="70551";
		boolean result=es.ValidateMobile(num);
		Assert.assertEquals(false, result);
	}
	
	
}
