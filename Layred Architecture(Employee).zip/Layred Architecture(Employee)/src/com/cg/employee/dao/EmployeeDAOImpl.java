package com.cg.employee.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;

public class EmployeeDAOImpl implements EmployeeDAO {
	Map<Integer, Employee> employeeMap;
	
	public EmployeeDAOImpl() {
		employeeMap = EmployeeDataStore.createCollection();
	}


	@Override
	public int addEmployee(Employee employee) throws EmployeeException {
		int empId = (int) (1000 * Math.random());
		employee.setEmpId(empId);
		employeeMap.put(empId,employee);
		return empId;
	}

	@Override
	public Employee searchEmployee(int empId) throws EmployeeException{
		Employee emp=employeeMap.get(empId);
		return emp;
	}

	@Override
	public Employee updateEmployee(Employee employee) throws EmployeeException{
		employeeMap.put(Employee.getEmpId(),employee);
		return employee;
	}

	@Override
	public ArrayList<Employee> getEmployeeList(String projName) throws EmployeeException{
		Collection<Employee> emplist = employeeMap.values();
		ArrayList<Employee> employee = new ArrayList<>();
		for (Employee e : emplist) // enhanced for loop
		{
			if (e.getProjName().equals(projName))

			{
				employee.add(e);
			}
		}
		return employee;
	}


}
