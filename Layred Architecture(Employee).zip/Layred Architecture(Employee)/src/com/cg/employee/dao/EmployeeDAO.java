package com.cg.employee.dao;

import java.util.ArrayList;

import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;

	public interface EmployeeDAO {
	public int addEmployee(Employee employee) throws EmployeeException;
	public Employee searchEmployee(int empId) throws EmployeeException;
	public Employee updateEmployee(Employee employee) throws EmployeeException;
	public ArrayList<Employee> getEmployeeList(String pname) throws EmployeeException;

}
