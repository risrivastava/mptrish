package com.cg.employee.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.employee.dto.Employee;

public class EmployeeDataStore {
	private static Map<Integer,Employee> employee;
	public static Map<Integer, Employee> createCollection()
	{
		if(employee==null)
			employee=new HashMap<>();
		return employee;
	}
}
